<template>
  <footer class="bg-gray-900 bg-opacity-80 py-6 mt-12">
    <div class="container mx-auto px-4 text-center text-gray-400 text-sm">
      <p>© 2023 神秘寻宝冒险 | 一个充满挑战的寻宝游戏</p>
      <p class="mt-2">探索未知，寻找传说中的宝藏</p>
    </div>
  </footer>
</template>